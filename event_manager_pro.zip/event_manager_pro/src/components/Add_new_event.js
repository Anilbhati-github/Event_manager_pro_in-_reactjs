import React, { Component } from 'react'

class Add extends Component {
    render() {
        return (
            <div>
                <form>
                <h1> Fill this form for add new event </h1>
                <p>Name of event:</p>
                <input
                    type="text"
                />
                <p>Place:</p>
                <input
                    type="text"
                />
                <p>Time of event:</p>
                <input
                    type="text"
                />
            </form>
                <button onClick>Submit</button>
            </div>
        );
    }
}



export default Add;