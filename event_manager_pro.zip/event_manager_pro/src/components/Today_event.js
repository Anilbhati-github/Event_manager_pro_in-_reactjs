import React, { Component } from 'react'

class Today_eve extends Component {
    render() {
        return (
            <div>

                <h1>ELEGANCE EVENTS</h1>
                <h2> Today Event </h2>
                <h2> Navratra Dance Program </h2>
                <p> Time of event - 7:00 pm </p>
                <p> Venue of event - Umeed bhawan palace</p>
                <p>Jodhpur</p>

            </div>
        );
    }
}

export default Today_eve;