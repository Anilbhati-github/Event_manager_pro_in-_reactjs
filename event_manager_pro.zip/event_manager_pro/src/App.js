import React , { Component } from "react";
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import Add from "./components/Add_new_event";
import Today_eve from "./components/Today_event";
import './App.css';


class User extends Component {
    render() {
        return (
            <Router >
                <div ClassName="User">
                    <ul>
                        <li>
                            <Link to="/Today_event">Home</Link>
                        </li>
                        <li>
                            <Link to="/Add_new_event">Add_new_event</Link>
                        </li>
                        <li>
                            <Link to="/Past_event">Past_event</Link>
                        </li>
                        <li>
                            <Link to="/Future_event">Future_event</Link>
                        </li>

                    </ul>

                    <Switch>
                        <Route exact path='/Add_new_event' component={Add}></Route>
                        <Route exact path='/Today_event' component={Today_eve}></Route>
    }
                        }/>
                    </Switch>
                </div>
            </Router>
        );
    }
}

// function App1() {
//     return (
//         <div  className="container">
//         </div>
//     );
// }
//
// export default App1;


export default User;